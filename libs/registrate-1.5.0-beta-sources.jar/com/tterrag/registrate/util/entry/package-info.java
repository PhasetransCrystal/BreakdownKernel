@javax.annotation.ParametersAreNonnullByDefault
@com.mojang.logging.annotations.MethodsReturnNonnullByDefault
@com.tterrag.registrate.util.nullness.FieldsAreNonnullByDefault
package com.tterrag.registrate.util.entry;
