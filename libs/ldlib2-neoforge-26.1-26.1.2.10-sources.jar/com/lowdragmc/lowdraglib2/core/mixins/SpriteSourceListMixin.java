package com.lowdragmc.lowdraglib2.core.mixins;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.renderer.texture.atlas.SpriteResourceLoader;
import net.minecraft.client.renderer.texture.atlas.SpriteSource;
import net.minecraft.client.renderer.texture.atlas.SpriteSourceList;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;

/**
 * @author KilaBash
 * @date 2023/7/20
 * @implNote SpriteSourceListMixin
 */
@Mixin(SpriteSourceList.class)
public abstract class SpriteSourceListMixin {

    // try to load all renderer textures
    @Inject(method = "load", at = @At(value = "RETURN"))
    private static void ldlib2$injectLoad(ResourceManager resourceManager, Identifier location, CallbackInfoReturnable<SpriteResourceLoader> cir,
                                   @Local List<SpriteSource> list) {
        // todo renderer
//        Identifier atlas = location.withPath("textures/atlas/%s.png"::formatted);
//        Set<Identifier> sprites = new HashSet<>();
//        for (var renderer : IRenderer.EVENT_REGISTERS) {
//            renderer.onPrepareTextureAtlas(atlas, sprites::add);
//        }
//        for (Identifier sprite : sprites) {
//            list.add(new SingleFile(sprite, Optional.empty()));
//        }
    }
}
